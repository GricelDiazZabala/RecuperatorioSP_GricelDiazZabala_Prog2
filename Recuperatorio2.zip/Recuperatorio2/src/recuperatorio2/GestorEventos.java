
package recuperatorio2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Evento;
import service.Agendable;
import service.CSVSerializable;
import java.time.LocalDate;

public class GestorEventos<T extends CSVSerializable> implements Agendable<T>{

    List<T> lista = new ArrayList<T>();
    @Override
    public void agregar(T item) {
    lista.add(item);
    }

    @Override
    public T obtener(int indice) {
    return lista.get(indice);
    }

    @Override
    public void eliminar(int indice) {
    lista.get(indice);
    }

    @Override
    public List<T> filtrar(Predicate<T> predicado) {
        List<T> toReturn = new ArrayList<>();
        for(T item:lista){
            if(predicado.test(item)){
                toReturn.add(item);
            }
        }
        return toReturn;
    }

    @Override
    public void ordenar() {
    ordenar((Comparator<T>) Comparator.naturalOrder());
    }

    @Override
    public void ordenar(Comparator<T> comparador) {
    lista.sort(comparador);
    }

    @Override
    public void serializar(String path) {
                try(ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))){
                
                salida.writeObject(lista);
            }catch (IOException ex){
                System.out.println(ex.getMessage());
            }
    }

    @Override
    public void deserializar(String path) {

        try(ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))){
                
        lista = (List<T>) input.readObject();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(GestorEventos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void guardarCSV(String path) {
        
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(path))){
            bw.write("id,titulo,autor,catgoria\n");
            for(T item:lista){
                bw.write(item.toCSV());
            }
        } catch (IOException ex) {
            throw new RuntimeException("Error en archivo");
        }        
    
        
    }
    
    @Override
    public void cargarCSV(String path) {
        lista.clear();
        try(BufferedReader bf = new BufferedReader(new FileReader(path))){
        String linea;
        while((linea = bf.readLine()) != null){
            lista.add(funcion.apply(linea));
        }
        } catch (IOException ex) {
            throw new RuntimeException("Error en archivo");
        }  
    }

    @Override
    public void mostrarTodos(Consumer<T> consumer) {
        for(T item:lista){
            consumer.accept(item);
        }
    }

    @Override
    public List<Evento> buscarPorRango(LocalDate inicio, LocalDate fin) {
        List<Evento> eventosEnRango = new ArrayList<>();
        for (Evento evento : eventos) {
            if ((evento.getFecha().isEqual(inicio) || evento.getFecha().isAfter(inicio)) &&
                (evento.getFecha().isEqual(fin) || evento.getFecha().isBefore(fin))) {
                eventosEnRango.add(evento);
            }
        }
        
        return eventosEnRango;
    }

    void guardarEnBinario(String eventosbin) {
            }

    void limpiar() {
            }

    void cargarDesdeBinario(String eventosbin) {
    
    }



}

