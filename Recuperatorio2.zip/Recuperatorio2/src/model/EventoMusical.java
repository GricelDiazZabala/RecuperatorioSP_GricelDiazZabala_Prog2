package model;

import java.time.LocalDate;

public class EventoMusical extends Evento implements Comparable<EventoMusical>{
    
    String artista;
    GeneroMusical genero;
    

    public EventoMusical(int id, String artista, LocalDate fecha, String nombre, GeneroMusical genero) {
        super(id, nombre, fecha);
        this.artista = artista;
        this.genero = genero;
    }

    public GeneroMusical getGenero() {
        return genero;
    }

    public String getArtista() {
        return artista;
    }
    
    
    @Override
    public int compareTo(EventoMusical otro) {
    return Integer.compare(id, otro.id);
    }
    
    public static EventoMusical fromCSV(String libroCSV) {

        String[] valores = libroCSV.split(",");

        return new EventoMusical(
                Integer.parseInt(valores[0]),
                valores[1],
                fecha.toString(valores[2]),
                valores[3],
                GeneroMusical.valueOf(valores[4]));

    }
}
